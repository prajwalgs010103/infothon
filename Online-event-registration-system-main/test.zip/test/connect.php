<?php
    $firstName = isset($_POST['firstName']) ? $_POST['firstName'] : '';
    $lastName = isset($_POST['lastName']) ? $_POST['lastName'] : '';
    $gender = isset($_POST['gender']) ? $_POST['gender'] : '';
    $email = isset($_POST['email']) ? $_POST['email'] : '';
    $event_id = isset($_POST['event_id']) ? $_POST['event_id'] : '';
    $age = isset($_POST['age']) ? $_POST['age'] : '';
    $phoneNumber = isset($_POST['phoneNumber']) ? $_POST['phoneNumber'] : '';

    // Check if any required field is empty
    if (empty($firstName) || empty($lastName) || empty($gender) || empty($email) || empty($event_id) || empty($age) || empty($phoneNumber)) {
        echo '<script>alert("Please fill in all the details.");</script>';
    } else {
        // Database connection
        $conn = new mysqli('localhost', 'root', '', 'test');
        if ($conn->connect_error) {
            echo "$conn->connect_error";
            die("Connection Failed: " . $conn->connect_error);
        } else {
            $checkUser = "SELECT * FROM registration WHERE email = '$email'";
            $result = mysqli_query($conn, $checkUser);
            $count = mysqli_num_rows($result);
            if ($count > 0) {
                echo '<script>alert("User already registered.");</script>';
            } else {
                $stmt = $conn->prepare("INSERT INTO registration (firstName, lastName, gender, email, event_id, age, phoneNumber) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("sssssii", $firstName, $lastName, $gender, $email, $event_id, $age, $phoneNumber);
                $execval = $stmt->execute();
                echo '<script>alert("Registration successful.");</script>';
                $stmt->close();
            }

            $conn->close();
        }
    }
?>